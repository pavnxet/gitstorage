# Secure GitHub Storage - Vercel - Explorer v3

Secure file explorer backed by GitHub Contents API, deployable on Vercel.

## Why 403 fix
Fine-grained PAT: Select storage repo only (not all repos), Permissions: Contents Read/Write + Metadata Read. Or use classic token with `repo` scope.

## Env Vars (Vercel)
```
GITHUB_TOKEN=ghp_... or github_pat_...
GITHUB_OWNER=pavnxet
GITHUB_REPO=my-storage
GITHUB_BRANCH=main
SITE_PASSWORD=strong_password_here
```

## Features v3
- Fail-closed auth (no bypass if SITE_PASSWORD missing)
- HttpOnly; SameSite=Lax; Secure cookies
- Path traversal protection with triple-decode + .git/.github block (allows .gitkeep)
- 3MB upload limit (server + client) to avoid Vercel 4.5MB body limit
- Proxy download via /api/file with Content-Disposition: attachment + nosniff
- Rename, Copy, Move, Delete, Trash (soft delete to trash/)
- Bulk select + ZIP download (jszip client-side)
- Search, Sort (name/size/type), Breadcrumbs
- List / Grid view with thumbnails
- Favorites ⭐ + Recent + Details panel
- File History via GitHub commits API
- Storage stats (repo size)
- Safe HTML preview (sandbox without scripts by default)
- Responsive mobile, dark/light theme

## .gitignore
uploads/, trash/, node_modules, .next, .env are ignored.
