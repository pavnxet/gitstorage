import { NextResponse } from 'next/server';

export function middleware(req) {
  const pass = process.env.SITE_PASSWORD;
  const { pathname } = req.nextUrl;

  // Public assets
  if (
    pathname.startsWith('/login') ||
    pathname.startsWith('/api/auth') ||
    pathname.startsWith('/_next') ||
    pathname === '/favicon.ico' ||
    pathname.startsWith('/favicon')
  ) {
    return NextResponse.next();
  }

  // Fail CLOSED - do not allow if password missing
  if (!pass || !pass.trim()) {
    if (pathname.startsWith('/api/')) {
      return NextResponse.json({ error: 'Server misconfigured: SITE_PASSWORD missing' }, { status: 500 });
    }
    return NextResponse.redirect(new URL('/login?error=misconfigured', req.url));
  }

  const cookie = req.cookies.get('site_auth')?.value;
  const authHeader = req.headers.get('authorization') || '';

  const isAuthed = cookie === pass || authHeader === `Bearer ${pass}`;

  if (isAuthed) {
    return NextResponse.next();
  }

  if (pathname.startsWith('/api/')) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  return NextResponse.redirect(new URL('/login', req.url));
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)']
};
