'use client';
import { useState, useEffect, useMemo, useRef } from 'react';

export default function Page() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [path, setPath] = useState('uploads');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [theme, setTheme] = useState('dark');
  const [previewFile, setPreviewFile] = useState(null);
  const [htmlMode, setHtmlMode] = useState('safe');
  const [viewMode, setViewMode] = useState('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('name');
  const [sortAsc, setSortAsc] = useState(true);
  const [selected, setSelected] = useState(new Set());
  const [favorites, setFavorites] = useState([]);
  const [recent, setRecent] = useState([]);
  const [showFavOnly, setShowFavOnly] = useState(false);
  const [showDetails, setShowDetails] = useState(null);
  const [stats, setStats] = useState(null);
  const [historyData, setHistoryData] = useState(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    setTheme(localStorage.getItem('site_theme') || 'dark');
    setFavorites(JSON.parse(localStorage.getItem('site_favs') || '[]'));
    setRecent(JSON.parse(localStorage.getItem('site_recent') || '[]'));
    const last = localStorage.getItem('site_last_path');
    const init = last !== null ? last : 'uploads';
    setPath(init); fetchFiles(init); fetchStats();
  }, []);

  const toggleTheme = () => { const n = theme === 'dark' ? 'light' : 'dark'; setTheme(n); localStorage.setItem('site_theme', n); };
  const fetchStats = async () => { try { const r = await fetch('/api/stats'); if (r.ok) setStats(await r.json()); } catch {} };

  const fetchFiles = async (p = path) => {
    setLoading(true); setErrorMsg(''); setSelected(new Set());
    try {
      const res = await fetch(`/api/files?path=${encodeURIComponent(p)}`);
      const data = await res.json();
      if (data.files) setFiles(data.files);
      else if (data.error) setErrorMsg(data.error);
    } catch (e) { setErrorMsg(e.message); }
    setLoading(false);
  };
  const changePath = (newPath) => { setPath(newPath); localStorage.setItem('site_last_path', newPath); fetchFiles(newPath); };

  const breadcrumbs = useMemo(() => {
    const parts = path.split('/').filter(Boolean);
    const crumbs = [{ name: 'root', path: '' }];
    let acc = '';
    parts.forEach(pt => { acc = acc ? `${acc}/${pt}` : pt; crumbs.push({ name: pt, path: acc }); });
    return crumbs;
  }, [path]);

  const filtered = useMemo(() => {
    let out = [...files];
    if (searchQuery) out = out.filter(f => f.name.toLowerCase().includes(searchQuery.toLowerCase()));
    if (showFavOnly) out = out.filter(f => favorites.includes(f.path));
    out.sort((a,b) => {
      let c = 0;
      if (sortBy === 'name') c = a.name.localeCompare(b.name);
      else if (sortBy === 'size') c = (a.size||0)-(b.size||0);
      else if (sortBy === 'type') c = a.type.localeCompare(b.type);
      return sortAsc ? c : -c;
    });
    out.sort((a,b) => a.type==='dir' && b.type!=='dir' ? -1 : b.type==='dir' && a.type!=='dir' ? 1 : 0);
    return out;
  }, [files, searchQuery, sortBy, sortAsc, favorites, showFavOnly]);

  const toggleSelect = (p) => { const n = new Set(selected); n.has(p) ? n.delete(p) : n.add(p); setSelected(n); };
  const toggleFav = (p) => { const n = favorites.includes(p) ? favorites.filter(x=>x!==p) : [...favorites, p]; setFavorites(n); localStorage.setItem('site_favs', JSON.stringify(n)); };
  const addRecent = (p) => { const n = [p, ...recent.filter(x=>x!==p)].slice(0,10); setRecent(n); localStorage.setItem('site_recent', JSON.stringify(n)); };

  const uploadFiles = async (list) => {
    if (!list?.length) return;
    setErrorMsg(''); setSuccessMsg(''); setUploading(true);
    let i=0;
    for (let file of list) {
      i++; setUploadProgress(`Uploading (${i}/${list.length}): ${file.name}...`);
      if (file.size > 3*1024*1024) { setErrorMsg(`"${file.name}" ${(file.size/1024/1024).toFixed(2)}MB > 3MB limit`); setUploading(false); setUploadProgress(''); return; }
      try {
        const b64 = await new Promise((res, rej) => {
          const r = new FileReader();
          r.onload = () => { const s = r.result; res(typeof s==='string' ? (s.split(',')[1]||s) : ''); };
          r.onerror = () => rej(r.error);
          r.readAsDataURL(file);
        });
        const upPath = path ? `${path}/${file.name}` : file.name;
        const resp = await fetch('/api/upload', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ path: upPath, content: b64, isBase64:true }) });
        const data = await resp.json();
        if (!resp.ok || !data.success) throw new Error(data.error||`Server ${resp.status}`);
      } catch (e) { setErrorMsg(`Upload failed ${file.name}: ${e.message}`); setUploading(false); setUploadProgress(''); fetchFiles(); return; }
    }
    setUploading(false); setUploadProgress(''); setSuccessMsg(`Uploaded ${list.length} file(s)`); fetchFiles(); setTimeout(()=>setSuccessMsg(''),3000);
  };

  const createFolder = async () => {
    const name = prompt('Folder name:'); if (!name?.trim()) return;
    try {
      const r = await fetch('/api/folder', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ name: name.trim(), path }) });
      const d = await r.json(); if (!r.ok || !d.success) setErrorMsg(d.error); else fetchFiles();
    } catch (e) { setErrorMsg(e.message); }
  };
  const rename = async (f) => {
    const nn = prompt(`Rename "${f.name}" to:`, f.name); if (!nn || nn.trim()===f.name) return;
    try {
      const r = await fetch('/api/rename', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ from: f.path, newName: nn.trim() }) });
      const d = await r.json(); if (!r.ok || !d.success) setErrorMsg(d.error); else { setSuccessMsg('Renamed'); fetchFiles(); }
    } catch (e) { setErrorMsg(e.message); }
  };
  const copy = async (src) => {
    const to = prompt(`Copy "${src}" to:`, `${path}/copy_${src.split('/').pop()}`); if (!to?.trim()) return;
    try { const r = await fetch('/api/copy', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ from: src, to: to.trim() }) }); const d = await r.json(); if (!r.ok || !d.success) setErrorMsg(d.error); else fetchFiles(); } catch (e) { setErrorMsg(e.message); }
  };
  const move = async (src) => {
    const to = prompt(`Move "${src}" to:`, src); if (!to?.trim() || to.trim()===src) return;
    try { const r = await fetch('/api/move', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ from: src, to: to.trim() }) }); const d = await r.json(); if (!r.ok || !d.success) setErrorMsg(d.error); else fetchFiles(); } catch (e) { setErrorMsg(e.message); }
  };
  const del = async (p, trash=true) => {
    if (!confirm(`${trash?'Move to trash':'Permanently delete'} ${p}?`)) return;
    try { const r = await fetch(`/api/delete?path=${encodeURIComponent(p)}${trash?'&trash=1':''}`, { method:'DELETE' }); const d = await r.json(); if (!r.ok || !d.success) setErrorMsg(d.error); else { setSuccessMsg(trash?'Moved to trash':'Deleted'); fetchFiles(); } } catch (e) { setErrorMsg(e.message); }
  };
  const bulkDel = async () => { if (!selected.size || !confirm(`Trash ${selected.size} items?`)) return; for (let p of selected) await fetch(`/api/delete?path=${encodeURIComponent(p)}&trash=1`, { method:'DELETE' }); setSelected(new Set()); fetchFiles(); };
  const bulkZip = async () => {
    if (!selected.size) return; setUploadProgress('Creating ZIP...');
    try {
      const JSZip = (await import('jszip')).default; const zip = new JSZip();
      for (let p of selected) {
        const f = files.find(x=>x.path===p); if (!f || f.type==='dir') continue;
        const res = await fetch(`/api/file?path=${encodeURIComponent(p)}`); if (!res.ok) continue;
        const blob = await res.blob(); zip.file(f.name, blob);
      }
      const content = await zip.generateAsync({ type:'blob' });
      const url = URL.createObjectURL(content); const a = document.createElement('a'); a.href=url; a.download=`${path.replace(/\//g,'_')||'files'}.zip`; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); setUploadProgress('');
    } catch (e) { setErrorMsg('ZIP failed: '+e.message); setUploadProgress(''); }
  };

  const openFile = async (f) => {
    if (f.type==='dir') { changePath(f.path); return; }
    addRecent(f.path); setHtmlMode('safe'); setPreviewFile({ file: f, content: null, loading: true });
    const ext = f.name.split('.').pop().toLowerCase();
    const textExts = ['txt','md','json','js','css','html','htm','py','ts','jsx','tsx','csv','log','xml','yaml','yml'];
    if (textExts.includes(ext)) {
      try { const r = await fetch(`/api/file?path=${encodeURIComponent(f.path)}`); const t = await r.text(); setPreviewFile({ file: f, content: t.slice(0,100000), loading: false }); }
      catch { setPreviewFile({ file: f, content: 'Failed', loading: false }); }
    } else setPreviewFile({ file: f, content: null, loading: false });
  };

  const viewHistory = async (f) => {
    try { const r = await fetch(`/api/history?path=${encodeURIComponent(f.path)}`); const d = await r.json(); if (d.history) setHistoryData({ file: f, history: d.history }); else setErrorMsg(d.error); } catch (e) { setErrorMsg(e.message); }
  };

  const logout = async () => { await fetch('/api/auth', { method:'DELETE' }); localStorage.removeItem('site_last_path'); window.location.href='/login'; };
  const fmt = (b) => { if (b===0||b===undefined) return '-'; if (b<1024) return b+' B'; if (b<1024*1024) return (b/1024).toFixed(1)+' KB'; return (b/1024/1024).toFixed(1)+' MB'; };

  const isDark = theme==='dark';
  const s = { bg: isDark ? '#09090b' : '#fff', text: isDark ? '#e4e4e7' : '#18181b', border: isDark ? '#27272a' : '#e4e4e7', subtle: isDark ? '#18181b' : '#f4f4f5', card: isDark ? '#121215' : '#f4f4f5', alt: isDark ? '#0d0d10' : '#fafafa', muted: isDark ? '#a1a1aa' : '#71717a', link: isDark ? '#60a5fa' : '#2563eb', btn: isDark ? '#27272a' : '#e4e4e7', btnT: isDark ? '#fff' : '#18181b' };

  return (
    <div style={{ maxWidth: 1200, margin: '0 auto', padding: '20px 16px', fontFamily: 'monospace, system-ui', color: s.text, background: s.bg, minHeight: '100vh' }}>
      <style jsx global>{`@media(max-width:640px){.hc{flex-direction:column!important;align-items:flex-start!important;gap:10px!important}.cg{width:100%!important;flex-wrap:wrap!important}.uz{flex-direction:column!important}}`}</style>

      <div className="hc" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: `1px solid ${s.border}`, paddingBottom: 12, flexWrap: 'wrap', gap: 8 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 700, margin: 0, fontFamily: 'system-ui' }}>Secure Storage</h1>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 6 }}>
            {breadcrumbs.map((b,i) => (
              <span key={b.path} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span onClick={()=>changePath(b.path)} style={{ cursor: 'pointer', color: i===breadcrumbs.length-1 ? s.text : s.link, fontWeight: i===breadcrumbs.length-1 ? 700 : 400, fontSize: 12 }}>{b.name}</span>
                {i < breadcrumbs.length-1 && <span style={{ color: s.muted }}>/</span>}
              </span>
            ))}
          </div>
          <p style={{ color: s.muted, fontSize: 11, margin: '4px 0 0 0' }}>{loading ? 'Loading...' : `${filtered.length}/${files.length} items`}{stats ? ` • ${(stats.sizeKB/1024).toFixed(1)}MB repo` : ''}</p>
        </div>
        <div className="cg" style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
          <input value={searchQuery} onChange={e=>setSearchQuery(e.target.value)} placeholder="🔍 Search" style={{ padding: '6px 10px', background: s.card, border: `1px solid ${s.border}`, borderRadius: 6, color: s.text, fontSize: 12, width: 130 }} />
          <select value={sortBy} onChange={e=>setSortBy(e.target.value)} style={{ padding: '6px', background: s.card, border: `1px solid ${s.border}`, borderRadius: 6, color: s.text, fontSize: 11 }}><option value="name">Name</option><option value="size">Size</option><option value="type">Type</option></select>
          <button onClick={()=>setSortAsc(!sortAsc)} style={{ padding: '6px 8px', background: s.btn, border: `1px solid ${s.border}`, borderRadius: 6, fontSize: 11, cursor: 'pointer' }}>{sortAsc?'↑':'↓'}</button>
          <button onClick={()=>setViewMode(viewMode==='list'?'grid':'list')} style={{ padding: '6px 10px', background: s.btn, border: `1px solid ${s.border}`, borderRadius: 6, fontSize: 11 }}>{viewMode==='list'?'🔲':'📋'}</button>
          <button onClick={createFolder} style={{ padding: '6px 10px', background: s.link, color: 'white', border: 'none', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>+ Folder</button>
          <button onClick={toggleTheme} style={{ padding: '6px 10px', background: s.btn, border: `1px solid ${s.border}`, borderRadius: 6, fontSize: 11 }}>{isDark?'☀':'🌙'}</button>
          <button onClick={()=>fetchFiles()} style={{ padding: '6px 10px', background: s.btn, border: `1px solid ${s.border}`, borderRadius: 6, fontSize: 11 }}>🔄</button>
          <button onClick={logout} style={{ padding: '6px 10px', background: '#3f3f46', color: 'white', border: 'none', borderRadius: 6, fontSize: 11 }}>Logout</button>
        </div>
      </div>

      {selected.size>0 && (
        <div style={{ marginTop: 12, padding: '8px 12px', background: s.card, border: `1px solid ${s.border}`, borderRadius: 8, display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
          <span style={{ fontSize: 12, fontWeight: 600 }}>{selected.size} selected</span>
          <button onClick={bulkZip} style={{ padding: '4px 10px', background: s.link, color: 'white', border: 'none', borderRadius: 4, fontSize: 11, cursor: 'pointer' }}>⬇ Zip</button>
          <button onClick={bulkDel} style={{ padding: '4px 10px', background: '#7f1d1d', color: 'white', border: 'none', borderRadius: 4, fontSize: 11, cursor: 'pointer' }}>🗑 Trash</button>
          <button onClick={()=>setSelected(new Set())} style={{ padding: '4px 10px', background: s.btn, border: `1px solid ${s.border}`, borderRadius: 4, fontSize: 11 }}>Clear</button>
        </div>
      )}

      <div style={{ marginTop: 10, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <button onClick={()=>setShowFavOnly(!showFavOnly)} style={{ padding: '4px 10px', background: showFavOnly ? '#facc15' : s.btn, color: showFavOnly ? 'black' : s.btnT, border: `1px solid ${s.border}`, borderRadius: 20, fontSize: 11, cursor: 'pointer' }}>⭐ {showFavOnly ? 'All' : `Favs (${favorites.length})`}</button>
        <button onClick={()=>{ changePath(path==='trash' ? 'uploads' : 'trash'); }} style={{ padding: '4px 10px', background: path==='trash' ? '#f87171' : s.btn, color: path==='trash' ? 'white' : s.btnT, border: `1px solid ${s.border}`, borderRadius: 20, fontSize: 11, cursor: 'pointer' }}>🗑 {path==='trash' ? 'Back' : 'Trash'}</button>
        {recent.length>0 && <span style={{ fontSize: 11, color: s.muted, padding: '4px' }}>Recent: {recent.slice(0,3).map(r=>r.split('/').pop()).join(', ')}</span>}
      </div>

      {errorMsg && <div style={{ marginTop: 12, padding: '10px 14px', background: '#450a0a', border: '1px solid #991b1b', borderRadius: 8, color: '#fca5a5', fontSize: 12, display: 'flex', justifyContent: 'space-between' }}><span><b>Error:</b> {errorMsg}</span><button onClick={()=>setErrorMsg('')} style={{ background: 'none', border: 'none', color: '#fca5a5', cursor: 'pointer' }}>✕</button></div>}
      {successMsg && <div style={{ marginTop: 12, padding: '10px 14px', background: '#052e16', border: '1px solid #15803d', borderRadius: 8, color: '#bbf7d0', fontSize: 12 }}>{successMsg}</div>}

      <div className="uz" onDragOver={e=>{e.preventDefault(); setIsDragging(true);}} onDragLeave={e=>{e.preventDefault(); setIsDragging(false);}} onDrop={e=>{e.preventDefault(); setIsDragging(false); if(e.dataTransfer.files?.length) uploadFiles(e.dataTransfer.files);}} onClick={()=>fileInputRef.current?.click()} style={{ marginTop: 14, background: isDragging ? s.card : s.bg, border: `2px dashed ${isDragging ? s.link : s.border}`, borderRadius: 10, padding: '14px 18px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }}>
        <input ref={fileInputRef} type="file" multiple onChange={e=>{uploadFiles(e.target.files); e.target.value='';}} style={{ display: 'none' }} />
        <div><h4 style={{ margin: 0, fontSize: 13, fontWeight: 600 }}>{uploading ? 'Uploading...' : `Upload to /${path||'root'}`}</h4><p style={{ margin: '2px 0 0 0', fontSize: 11, color: s.muted }}>Drag & drop or click (Max 3MB)</p></div>
        <button disabled={uploading} onClick={e=>{e.stopPropagation(); fileInputRef.current?.click();}} style={{ padding: '6px 14px', background: isDark ? 'white' : '#18181b', color: isDark ? 'black' : 'white', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>{uploading?'...':'Browse'}</button>
      </div>
      {uploadProgress && <div style={{ marginTop: 8, fontSize: 11, color: s.link, fontWeight: 600 }}>{uploadProgress}</div>}

      {viewMode==='list' ? (
        <div style={{ marginTop: 16, overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: 12, minWidth: 600 }}>
            <thead><tr style={{ borderBottom: `2px solid ${s.border}`, color: s.muted }}><th style={{ padding: '8px 6px', width: 30 }}><input type="checkbox" checked={selected.size===filtered.length && filtered.length>0} onChange={()=>{ if(selected.size===filtered.length) setSelected(new Set()); else setSelected(new Set(filtered.map(f=>f.path))); }} /></th><th style={{ padding: '8px 6px' }}>Name</th><th style={{ padding: '8px 6px', width: 70 }}>Type</th><th style={{ padding: '8px 6px', width: 80, textAlign: 'right' }}>Size</th><th style={{ padding: '8px 6px', width: 300, textAlign: 'center' }}>Actions</th></tr></thead>
            <tbody>
              {path && <tr onClick={()=>{ const p=path.split('/'); p.pop(); changePath(p.join('/')); }} style={{ borderBottom: `1px solid ${s.subtle}`, cursor: 'pointer', background: s.card }}><td colSpan={5} style={{ padding: '8px 6px', color: s.link, fontWeight: 600 }}>📁 ../ Parent</td></tr>}
              {filtered.length===0 && !loading && <tr><td colSpan={5} style={{ padding: 20, textAlign: 'center', color: s.muted }}>{searchQuery ? 'No match' : 'Empty'}</td></tr>}
              {filtered.map((f, idx) => (
                <tr key={f.sha||idx} style={{ borderBottom: `1px solid ${s.subtle}`, background: idx%2===0 ? s.bg : s.alt }}>
                  <td style={{ padding: '6px' }}><input type="checkbox" checked={selected.has(f.path)} onChange={()=>toggleSelect(f.path)} /></td>
                  <td style={{ padding: '6px', wordBreak: 'break-word' }}>
                    <span onClick={()=>openFile(f)} style={{ cursor: 'pointer', color: f.type==='dir'? s.link : s.text, fontWeight: f.type==='dir'?600:400 }}>{f.type==='dir'?`📁 ${f.name}/`:`📄 ${f.name}`}</span>
                    {favorites.includes(f.path) && <span style={{ marginLeft: 6 }}>⭐</span>}
                  </td>
                  <td style={{ padding: '6px', color: s.muted, fontSize: 11 }}>{f.type}</td>
                  <td style={{ padding: '6px', textAlign: 'right', color: s.muted }}>{fmt(f.size)}</td>
                  <td style={{ padding: '6px', textAlign: 'center' }}>
                    <div style={{ display: 'flex', gap: 3, justifyContent: 'center', flexWrap: 'wrap' }}>
                      {f.type==='file' && <a href={`/api/file?path=${encodeURIComponent(f.path)}&download=1`} style={{ padding: '3px 6px', background: s.btn, color: s.btnT, borderRadius: 4, fontSize: 10, textDecoration: 'none' }}>DL</a>}
                      <button onClick={()=>toggleFav(f.path)} style={{ padding: '3px 6px', background: favorites.includes(f.path)?'#facc15':s.btn, border: 'none', borderRadius: 4, fontSize: 10, cursor: 'pointer' }}>⭐</button>
                      <button onClick={()=>setShowDetails(f)} style={{ padding: '3px 6px', background: s.btn, border: `1px solid ${s.border}`, borderRadius: 4, fontSize: 10, cursor: 'pointer' }}>i</button>
                      <button onClick={()=>rename(f)} style={{ padding: '3px 6px', background: '#1e3a8a', color: 'white', border: 'none', borderRadius: 4, fontSize: 10, cursor: 'pointer' }}>Ren</button>
                      <button onClick={()=>viewHistory(f)} style={{ padding: '3px 6px', background: '#3f3f46', color: 'white', border: 'none', borderRadius: 4, fontSize: 10, cursor: 'pointer' }}>Hist</button>
                      <button onClick={()=>del(f.path,true)} style={{ padding: '3px 6px', background: '#7f1d1d', color: 'white', border: 'none', borderRadius: 4, fontSize: 10, cursor: 'pointer' }}>Del</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div style={{ marginTop: 16, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 10 }}>
          {filtered.map(f => (
            <div key={f.path} onClick={()=>openFile(f)} style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 10, padding: 10, cursor: 'pointer', position: 'relative' }}>
              <input type="checkbox" checked={selected.has(f.path)} onChange={e=>{e.stopPropagation(); toggleSelect(f.path);}} style={{ position: 'absolute', top: 6, left: 6 }} />
              <div style={{ fontSize: 24, textAlign: 'center', marginTop: 10 }}>{f.type==='dir' ? '📁' : f.name.match(/\.(jpg|jpeg|png|gif|webp|svg)$/i) ? '🖼️' : f.name.endsWith('.pdf') ? '📕' : '📄'}</div>
              <div style={{ fontSize: 11, fontWeight: 600, marginTop: 8, textAlign: 'center', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{f.name}</div>
              <div style={{ fontSize: 10, color: s.muted, textAlign: 'center' }}>{fmt(f.size)}</div>
            </div>
          ))}
        </div>
      )}

      {showDetails && (
        <div style={{ position: 'fixed', top: 0, right: 0, width: 320, maxWidth: '85vw', height: '100vh', background: s.card, borderLeft: `1px solid ${s.border}`, padding: 16, zIndex: 50, overflow: 'auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><h3 style={{ margin: 0, fontSize: 14 }}>Details</h3><button onClick={()=>setShowDetails(null)} style={{ background: 'none', border: 'none', fontSize: 18, cursor: 'pointer', color: s.text }}>✕</button></div>
          <div style={{ marginTop: 12, fontSize: 12, lineHeight: 1.6 }}>
            <p><b>Name:</b> {showDetails.name}</p><p><b>Path:</b> {showDetails.path}</p><p><b>Type:</b> {showDetails.type}</p><p><b>Size:</b> {fmt(showDetails.size)}</p><p><b>SHA:</b> <span style={{ fontSize: 10, wordBreak: 'break-all' }}>{showDetails.sha}</span></p>
            <div style={{ marginTop: 10, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              <a href={`/api/file?path=${encodeURIComponent(showDetails.path)}&download=1`} style={{ padding: '6px 10px', background: s.link, color: 'white', borderRadius: 6, textDecoration: 'none', fontSize: 11 }}>Download</a>
              <button onClick={()=>toggleFav(showDetails.path)} style={{ padding: '6px 10px', background: favorites.includes(showDetails.path) ? '#facc15' : s.btn, borderRadius: 6, fontSize: 11 }}>{favorites.includes(showDetails.path) ? 'Unstar' : 'Star'}</button>
            </div>
          </div>
        </div>
      )}

      {previewFile && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 12 }}>
          <div style={{ background: s.card, color: s.text, border: `1px solid ${s.border}`, borderRadius: 12, maxWidth: 950, width: '100%', maxHeight: '92vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <div style={{ padding: '12px 16px', borderBottom: `1px solid ${s.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ margin: 0, fontSize: 14, wordBreak: 'break-all' }}>📄 {previewFile.file.name}</h3>
              <div style={{ display: 'flex', gap: 6 }}><a href={`/api/file?path=${encodeURIComponent(previewFile.file.path)}&download=1`} style={{ padding: '5px 10px', background: s.btn, color: s.btnT, borderRadius: 6, fontSize: 11, textDecoration: 'none' }}>⬇ Download</a><button onClick={()=>setPreviewFile(null)} style={{ background: 'none', border: 'none', color: s.text, fontSize: 18, cursor: 'pointer' }}>✕</button></div>
            </div>
            <div style={{ padding: 16, overflow: 'auto', flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              {previewFile.loading ? <p style={{ opacity: 0.6 }}>Loading...</p> : (() => {
                const ext = previewFile.file.name.split('.').pop().toLowerCase();
                const imgExts = ['jpg','jpeg','png','gif','webp','svg'];
                if (['html','htm'].includes(ext) && previewFile.content) {
                  return (
                    <div style={{ width: '100%' }}>
                      <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
                        <button onClick={()=>setHtmlMode('safe')} style={{ padding: '5px 12px', background: htmlMode==='safe'? s.link : s.btn, color: htmlMode==='safe' ? 'white' : s.btnT, border: 'none', borderRadius: 6, fontSize: 11, cursor: 'pointer' }}>Safe Preview</button>
                        <button onClick={()=>{ if(confirm('Allow scripts? Unsafe!')) setHtmlMode('unsafe'); }} style={{ padding: '5px 12px', background: htmlMode==='unsafe'? '#dc2626' : s.btn, color: htmlMode==='unsafe' ? 'white' : s.btnT, border: 'none', borderRadius: 6, fontSize: 11, cursor: 'pointer' }}>Unsafe</button>
                      </div>
                      {htmlMode==='safe' ? <iframe srcDoc={previewFile.content} sandbox="" title={previewFile.file.name} style={{ width: '100%', height: '60vh', border: 'none', background: 'white', borderRadius: 8 }} /> : <iframe srcDoc={previewFile.content} sandbox="allow-scripts" title={previewFile.file.name} style={{ width: '100%', height: '60vh', border: 'none', background: 'white', borderRadius: 8 }} />}
                    </div>
                  );
                }
                if (imgExts.includes(ext)) return <img src={`/api/file?path=${encodeURIComponent(previewFile.file.path)}`} alt={previewFile.file.name} style={{ maxWidth: '100%', maxHeight: '70vh', objectFit: 'contain', borderRadius: 8 }} />;
                if (ext==='pdf') return <iframe src={`/api/file?path=${encodeURIComponent(previewFile.file.path)}`} title={previewFile.file.name} style={{ width: '100%', height: '70vh', border: 'none', borderRadius: 8 }} />;
                if (['mp4','webm'].includes(ext)) return <video controls src={`/api/file?path=${encodeURIComponent(previewFile.file.path)}`} style={{ maxWidth: '100%', maxHeight: '70vh', borderRadius: 8 }} />;
                if (['mp3','wav','ogg'].includes(ext)) return <audio controls src={`/api/file?path=${encodeURIComponent(previewFile.file.path)}`} style={{ width: '100%' }} />;
                if (previewFile.content !== null) return <pre style={{ width: '100%', padding: 14, background: isDark ? '#000' : '#fff', border: `1px solid ${s.border}`, borderRadius: 8, fontSize: 12, overflow: 'auto', maxHeight: '65vh', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{previewFile.content}</pre>;
                return <div style={{ textAlign: 'center' }}><p>No preview</p><a href={`/api/file?path=${encodeURIComponent(previewFile.file.path)}&download=1`} style={{ padding: '8px 14px', background: s.link, color: 'white', borderRadius: 6, textDecoration: 'none', fontSize: 12 }}>Download</a></div>;
              })()}
            </div>
          </div>
        </div>
      )}

      {historyData && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1001, padding: 12 }}>
          <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 12, maxWidth: 600, width: '100%', maxHeight: '80vh', overflow: 'auto', padding: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><h3 style={{ margin: 0, fontSize: 14 }}>History: {historyData.file.name}</h3><button onClick={()=>setHistoryData(null)} style={{ background: 'none', border: 'none', fontSize: 18, cursor: 'pointer', color: s.text }}>✕</button></div>
            <div style={{ marginTop: 12 }}>
              {historyData.history.map(h => (
                <div key={h.sha} style={{ padding: '8px 0', borderBottom: `1px solid ${s.subtle}`, fontSize: 11 }}>
                  <div style={{ fontWeight: 600 }}>{h.message}</div>
                  <div style={{ color: s.muted }}>{h.author} • {new Date(h.date).toLocaleString()} • {h.sha.slice(0,7)}</div>
                  <a href={h.url} target="_blank" style={{ color: s.link, fontSize: 11 }}>View on GitHub</a>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div style={{ marginTop: 24, paddingTop: 12, borderTop: `1px solid ${s.subtle}`, color: s.muted, fontSize: 10, textAlign: 'center' }}>Explorer v3 • {path} • {favorites.length} starred • {recent.length} recent</div>
    </div>
  );
}
