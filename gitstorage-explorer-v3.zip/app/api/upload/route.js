import { saveFile } from '@/lib/github';
import { checkAuthFromRequest } from '@/lib/auth';
export async function POST(req) {
  if (!checkAuthFromRequest(req)) return Response.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const { path, content, isBase64 } = body || {};
    if (!path) return Response.json({ error: 'File path required' }, { status: 400 });
    if (!content) return Response.json({ error: 'Content required' }, { status: 400 });
    const b64Len = isBase64 ? content.length : Buffer.from(content).toString('base64').length;
    const approx = Math.ceil(b64Len * 0.75);
    if (approx > 3 * 1024 * 1024) {
      return Response.json({ error: `Too large ${(approx/1024/1024).toFixed(2)}MB. Max 3MB` }, { status: 413 });
    }
    const base64 = isBase64 ? content : Buffer.from(content).toString('base64');
    const result = await saveFile(path, base64);
    return Response.json({ success: true, result });
  } catch (e) {
    console.error(e);
    return Response.json({ error: e.message || 'Upload failed' }, { status: 500 });
  }
}
