import { saveFile, sanitizePath } from '@/lib/github';
import { checkAuthFromRequest } from '@/lib/auth';
export async function POST(req) {
  if (!checkAuthFromRequest(req)) return Response.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const { name, path } = await req.json();
    if (!name || !name.trim()) return Response.json({ error: 'Folder name required' }, { status: 400 });
    const cleanFolder = name.trim().replace(/\//g,'').trim();
    if (!cleanFolder || cleanFolder.includes('/') || cleanFolder === '.' || cleanFolder === '..') return Response.json({ error: 'Invalid folder name' }, { status: 400 });
    sanitizePath(cleanFolder);
    const parent = path ? sanitizePath(path) : '';
    const full = parent ? `${parent}/${cleanFolder}/.gitkeep` : `${cleanFolder}/.gitkeep`;
    const result = await saveFile(full, Buffer.from('').toString('base64'));
    return Response.json({ success: true, result });
  } catch (e) {
    console.error(e);
    return Response.json({ error: e.message || 'Failed' }, { status: 500 });
  }
}
