import { deleteFile, moveToTrash } from '@/lib/github';
import { checkAuthFromRequest } from '@/lib/auth';
export async function DELETE(req) {
  if (!checkAuthFromRequest(req)) return Response.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const path = searchParams.get('path');
  const useTrash = searchParams.get('trash') === '1';
  if (!path) return Response.json({ error: 'path required' }, { status: 400 });
  try {
    if (useTrash) {
      const trashPath = await moveToTrash(path);
      return Response.json({ success: true, trashed: true, trashPath });
    }
    await deleteFile(path);
    return Response.json({ success: true });
  } catch (e) {
    console.error(e);
    return Response.json({ error: e.message || 'Delete failed' }, { status: 500 });
  }
}
