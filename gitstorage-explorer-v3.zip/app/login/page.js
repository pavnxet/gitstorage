'use client';
import { useState } from 'react';
export default function Login() {
  const [pw, setPw] = useState(''); const [err, setErr] = useState(''); const [loading, setLoading] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setLoading(true); setErr('');
    try {
      const res = await fetch('/api/auth', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ password: pw }) });
      const data = await res.json();
      if (data.success) window.location.href = '/';
      else setErr(data.error || 'Wrong password');
    } catch { setErr('Login failed'); }
    setLoading(false);
  };
  return (
    <div style={{minHeight:'100vh', display:'grid', placeItems:'center', background:'#09090b', padding:16}}>
      <form onSubmit={submit} style={{background:'#18181b', padding:32, borderRadius:16, width:'100%', maxWidth:360, border:'1px solid #27272a'}}>
        <h2 style={{margin:0, fontSize:20, fontWeight:700, color:'white'}}>Protected Storage</h2>
        <p style={{opacity:0.6, fontSize:13, color:'#a1a1aa', marginTop:4}}>Enter password to access explorer</p>
        <input type="password" value={pw} onChange={e=>setPw(e.target.value)} placeholder="Password" autoFocus style={{width:'100%', marginTop:16, padding:12, borderRadius:8, background:'#27272a', border:'1px solid #3f3f46', color:'white', boxSizing:'border-box'}} />
        {err && <p style={{color:'#f87171', fontSize:12, marginTop:8}}>{err}</p>}
        <button type="submit" disabled={loading} style={{width:'100%', marginTop:16, padding:12, background:'white', color:'black', borderRadius:8, fontWeight:700, border:'none', cursor:'pointer'}}>{loading ? 'Checking...' : 'Unlock'}</button>
      </form>
    </div>
  );
}
